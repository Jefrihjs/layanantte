

<?php $__env->startSection('page_title', 'Edit Permohonan TTE'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .form-card-edit {
        background: #ffffff;
        border-radius: 20px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);
    }
    .form-label-custom {
        font-size: 13px;
        font-weight: 700;
        color: #64748b;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .form-control-custom {
        border-radius: 12px;
        padding: 12px 15px;
        border: 2px solid #f1f5f9;
        background-color: #f8fafc;
        transition: all 0.3s ease;
    }
    .form-control-custom:focus {
        border-color: #0f766e;
        background-color: #fff;
        box-shadow: 0 0 0 4px rgba(15, 118, 110, 0.1);
    }
    .form-control-custom:disabled {
        background-color: #e2e8f0;
        cursor: not-allowed;
    }
    .btn-save {
        background: linear-gradient(135deg, #0f766e 0%, #115e59 100%);
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 12px;
        font-weight: 700;
        transition: 0.3s;
    }
    .btn-save:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(15, 118, 110, 0.3);
        color: white;
    }
    .section-title {
        font-size: 16px;
        font-weight: 800;
        color: #1e293b;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .section-title::after {
        content: "";
        flex: 1;
        height: 1px;
        background: #e2e8f0;
    }
</style>

<div class="container-fluid p-0">
    
    
    <div class="d-flex align-items-center gap-3 mb-4">
        <a href="<?php echo e(route('permohonan.index')); ?>" class="btn btn-light rounded-circle shadow-sm d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
            <i class="fa-solid fa-arrow-left text-muted"></i>
        </a>
        <div>
            <h4 class="fw-bold mb-0 text-dark">Edit Permohonan</h4>
            <p class="text-muted small mb-0">ID Permohonan: #<?php echo e($log->id); ?></p>
        </div>
    </div>

    <div class="card form-card-edit border-0">
        <div class="card-body p-5">
            
            <form method="POST" action="<?php echo e(route('permohonan.update', $log->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="section-title">
                    <i class="fa-solid fa-id-card text-teal"></i> Identitas Utama
                </div>
                
                <div class="row mb-4">
                    <div class="col-md-6 mb-3">
                        <label class="form-label-custom">NIK Pemohon</label>
                        <input type="text" class="form-control form-control-custom" value="<?php echo e($log->nik); ?>" disabled>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label-custom">NIP Pemohon</label>
                        <input type="text" class="form-control form-control-custom" value="<?php echo e($log->nip); ?>" disabled>
                    </div>
                </div>

                
                <div class="section-title">
                    <i class="fa-solid fa-pen-to-square text-teal"></i> Perbarui Data
                </div>

                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label-custom">Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control form-control-custom <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   value="<?php echo e(old('nama', $log->nama)); ?>" required>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label-custom">Nomor WhatsApp/HP</label>
                            <input type="text" name="no_hp" class="form-control form-control-custom <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   value="<?php echo e(old('no_hp', $log->no_hp)); ?>" required>
                            <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label-custom">Jabatan / Unit Kerja</label>
                            <input type="text" name="jabatan" class="form-control form-control-custom <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   value="<?php echo e(old('jabatan', $log->jabatan)); ?>" required>
                            <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="form-label-custom">Keterangan Tambahan</label>
                            <textarea name="keterangan" class="form-control form-control-custom <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                      rows="4" required><?php echo e(old('keterangan', $log->keterangan)); ?></textarea>
                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                
                <div class="d-flex justify-content-end gap-2 mt-5 pt-4 border-top">
                    <a href="<?php echo e(route('permohonan.index')); ?>" class="btn btn-light rounded-pill px-4 fw-bold text-muted border">
                        Batal
                    </a>
                    <button type="submit" class="btn btn-save rounded-pill shadow-sm">
                        <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Perubahan
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/permohonan/edit.blade.php ENDPATH**/ ?>