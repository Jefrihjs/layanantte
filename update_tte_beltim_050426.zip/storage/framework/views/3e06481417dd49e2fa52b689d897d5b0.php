<?php $__env->startSection('page_title', 'Daftar Permohonan TTE'); ?>

<?php $__env->startSection('content'); ?>
<style>
    /* Tambahan agar tampilan tabel lebih premium */
    .table thead th {
        background-color: #f8fafc;
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: 1px;
        color: #64748b;
        padding: 15px 10px;
        border-top: none;
    }
    .table tbody td {
        padding: 15px 10px;
        vertical-align: middle;
        border-color: #f1f5f9;
    }
    .badge-status {
        font-size: 11px;
        font-weight: 700;
        padding: 6px 12px;
        border-radius: 50px;
        text-transform: uppercase;
    }
    .filter-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 15px;
    }
    .btn-action {
        width: 32px;
        height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        transition: 0.2s;
    }
    .btn-action:hover {
        transform: scale(1.1);
    }
</style>

<div class="container-fluid p-0">
    
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1 text-dark">Data Permohonan</h4>
            <p class="text-muted small mb-0">Total ditemukan: <strong><?php echo e($data->total()); ?></strong> data permohonan</p>
        </div>
        <a href="<?php echo e(route('permohonan.export', request()->query())); ?>" class="btn btn-success rounded-pill px-4 shadow-sm fw-bold border-0">
            <i class="fa-solid fa-file-excel me-2"></i> Export Excel
        </a>
    </div>

    
    <div class="card filter-card shadow-sm mb-4">
        <div class="card-body p-4">
            <form method="GET" action="<?php echo e(route('permohonan.index')); ?>" class="row g-3">
                
                <div class="col-md-3">
                    <label class="small fw-bold text-muted mb-1">Cari Nama/NIK</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="fa-solid fa-magnifying-glass"></i></span>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control border-start-0 ps-0" placeholder="Ketik di sini...">
                    </div>
                </div>

                
                <div class="col-md-2">
                    <label class="small fw-bold text-muted mb-1">Tahun</label>
                    <select name="tahun" class="form-select form-select-sm shadow-none">
                        <option value="">Semua Tahun</option>
                        <?php for($i = date('Y'); $i >= 2024; $i--): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('tahun', date('Y')) == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label class="small fw-bold text-muted mb-1">Periode Triwulan</label>
                    <select name="triwulan" class="form-select form-select-sm shadow-none">
                        <option value="">Setahun Penuh</option>
                        <option value="1" <?php echo e(request('triwulan') == '1' ? 'selected' : ''); ?>>Triwulan I (Jan-Mar)</option>
                        <option value="2" <?php echo e(request('triwulan') == '2' ? 'selected' : ''); ?>>Triwulan II (Apr-Jun)</option>
                        <option value="3" <?php echo e(request('triwulan') == '3' ? 'selected' : ''); ?>>Triwulan III (Jul-Sep)</option>
                        <option value="4" <?php echo e(request('triwulan') == '4' ? 'selected' : ''); ?>>Triwulan IV (Okt-Des)</option>
                    </select>
                </div>

                
                <div class="col-md-2">
                    <label class="small fw-bold text-muted mb-1">Jenis Layanan</label>
                    <select name="jenis" class="form-select form-select-sm shadow-none">
                        <option value="">Semua Jenis</option>
                        <option value="baru" <?php echo e(request('jenis') == 'baru' ? 'selected' : ''); ?>>Pendaftaran Baru</option>
                        <option value="reset_passphrase" <?php echo e(request('jenis') == 'reset_passphrase' ? 'selected' : ''); ?>>Reset Passphrase</option>
                    </select>
                </div>

                
                <div class="col-md-3 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary btn-sm rounded-pill px-4 fw-bold w-100 shadow-sm">
                        <i class="fa-solid fa-filter me-1"></i> Filter
                    </button>
                    <a href="<?php echo e(route('permohonan.index')); ?>" class="btn btn-light btn-sm rounded-pill px-4 fw-bold w-100 border text-muted">
                        <i class="fa-solid fa-rotate-left me-1"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm" style="border-radius: 20px; overflow: hidden;">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Tanggal Masuk</th>
                        <th>Identitas Pemohon</th>
                        <th>Unit Kerja</th>
                        <th>Jenis Layanan</th>
                        <th class="text-center">Status</th>
                        <th class="text-center pe-4">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?php echo e($item->created_at->format('d M Y')); ?></div>
                                <small class="text-muted"><?php echo e($item->created_at->format('H:i')); ?> WIB</small>
                            </td>
                            <td>
                                <div class="fw-bold text-primary"><?php echo e($item->nama); ?></div>
                                <div class="text-muted small" style="letter-spacing: 0.5px;">NIK: <?php echo e($item->nik); ?></div>
                            </td>
                            <td>
                                <div class="small text-dark fw-medium" style="max-width: 200px; line-height: 1.4;"><?php echo e($item->unit_kerja); ?></div>
                            </td>
                            <td>
                                <?php
                                    $jenis_label = $item->jenis_permohonan == 'baru' ? 'Pendaftaran Baru' : ($item->jenis_permohonan == 'reset_passphrase' ? 'Reset Passphrase' : 'Perpanjangan');
                                    $jenis_color = $item->jenis_permohonan == 'baru' ? 'bg-primary' : 'bg-info text-dark';
                                ?>
                                <span class="badge <?php echo e($jenis_color); ?> bg-opacity-10 text-<?php echo e(explode(' ', $jenis_color)[0] == 'bg-primary' ? 'primary' : 'dark'); ?> small border-0 fw-bold px-3 py-2" style="font-size: 10px;">
                                    <?php echo e($jenis_label); ?>

                                </span>
                            </td>
                            <td class="text-center">
                                <?php if($item->status == 'diproses'): ?>
                                    <span class="badge-status bg-success bg-opacity-10 text-success border border-success border-opacity-25">
                                        <i class="fa-solid fa-circle-check me-1 small"></i> Diproses
                                    </span>
                                <?php else: ?>
                                    <span class="badge-status bg-warning bg-opacity-10 text-warning border border-warning border-opacity-25" style="color: #d97706 !important;">
                                        <i class="fa-solid fa-clock me-1 small"></i> Pending
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center pe-4">
                                <div class="d-flex justify-content-center gap-1">
                                    <button onclick="showDetail('<?php echo e(route('permohonan.detail', $item->id)); ?>')" 
                                            class="btn btn-action btn-light border text-primary" title="Lihat Detail">
                                        <i class="fa-solid fa-eye"></i>
                                    </button>
                                    
                                    <a href="<?php echo e(route('permohonan.edit', $item->id)); ?>" 
                                       class="btn btn-action btn-light border text-warning" title="Edit Data">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    
                                    <form action="<?php echo e(route('permohonan.destroy', $item->id)); ?>" method="POST" class="d-inline form-hapus">
                                        <?php echo csrf_field(); ?> 
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-action btn-light border text-danger btn-delete" title="Hapus">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                
                                <div class="mb-3">
                                    <i class="fa-solid fa-folder-open text-light" style="font-size: 80px; color: #e2e8f0 !important;"></i>
                                </div>
                                <h6 class="fw-bold text-muted">Data permohonan tidak ditemukan.</h6>
                                <p class="text-small text-muted">Coba sesuaikan filter atau kata kunci pencarian</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="mt-4 d-flex justify-content-center">
        <?php echo e($data->appends(request()->query())->links('pagination::bootstrap-5')); ?>

    </div>

</div>

<div class="modal fade" id="modalDetail" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="border-radius: 20px; border: none; overflow: hidden;">
            <div class="modal-header border-0 p-4" style="background: #0f766e; color: white;">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-file-lines me-2"></i> Detail Permohonan</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0" id="detailContent">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2 text-muted">Mengambil data...</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', function(e) {
            const form = this.closest('.form-hapus');
            
            Swal.fire({
                title: 'Yakin hapus data?',
                text: "Data yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#0f766e', // Warna Teal
                cancelButtonColor: '#64748b', // Warna Abu-abu
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal',
                border: 'none',
                borderRadius: '15px'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });

    // Bonus: Munculkan notifikasi jika berhasil hapus
    <?php if(session('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil!',
            text: "<?php echo e(session('success')); ?>",
            showConfirmButton: false,
            timer: 1500
        });
    <?php endif; ?>
</script>

<script>
    function showDetail(url) {
        // 1. Tampilkan Modal
        const myModal = new bootstrap.Modal(document.getElementById('modalDetail'));
        myModal.show();

        // 2. Reset konten ke loading spinner
        document.getElementById('detailContent').innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-teal" role="status" style="color: #0f766e;"></div>
                <p class="mt-2 text-muted small fw-bold">MEMUAT DATA...</p>
            </div>
        `;

        // 3. Ambil data pakai Fetch API (AJAX)
        fetch(url)
            .then(response => response.text())
            .then(html => {
                document.getElementById('detailContent').innerHTML = html;
            })
            .catch(error => {
                document.getElementById('detailContent').innerHTML = `
                    <div class="alert alert-danger m-3">Gagal mengambil data. Silakan coba lagi.</div>
                `;
            });
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/permohonan/index.blade.php ENDPATH**/ ?>